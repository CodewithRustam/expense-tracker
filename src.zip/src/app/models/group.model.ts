export interface Group {
  roomId: number;
  name: string;
  type: string;
  totalAmount: number;
  createdDate: string;
  memberNames: string;
  iconName: string;
  status: string;
  month : string;
}
