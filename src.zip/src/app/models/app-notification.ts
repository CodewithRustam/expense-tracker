export interface AppNotification {
  id: number;
  title: string;
  body: string;
  receivedAt: string;
  isRead: boolean;
}