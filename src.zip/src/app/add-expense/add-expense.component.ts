import { Component, Input } from '@angular/core';
import { ModalController, ToastController } from '@ionic/angular';
import { AddExpenseResponse, ExpenseService } from '../services/expense';
import { Group } from '../models/group.model';
import { Toastservice } from '../services/toastservice';

@Component({
  selector: 'app-add-expense-modal',
  templateUrl: './add-expense-modal.component.html',
  styleUrls: ['./add-expense-modal.component.scss'],
  standalone: false
})
export class AddExpenseModalComponent {
  @Input() groups: Group[] = [];
  @Input() users: { id: number, name: string }[] = [];
  readonly MAX_ITEM_LENGTH = 30;
  readonly DEFAULT_ROOM_NAME = 'General';
  
  newExpense = {
    item: '',
    amount: '',
    date: new Date().toISOString(),
    roomId: 0
  };
  filteredGroups: Group[] = [];
  showDatePicker = false;
  today = new Date().toISOString().split('T')[0];

  constructor(
    private modalCtrl: ModalController,
    private expenseService: ExpenseService,
    private toast: Toastservice
  ) { }

  dismiss(data?: any) {
    this.modalCtrl.dismiss(data);
  }
  ngOnInit() {
    this.filteredGroups = [...this.groups];
    if (this.groups.length > 0) {
      // 1. Try to find the room by name
      const defaultRoom = this.groups.find(
        g => g.name.toLowerCase() === this.DEFAULT_ROOM_NAME.toLowerCase()
      );

      // 2. If found, select it; otherwise, select the first one in the list
      if (defaultRoom) {
        this.newExpense.roomId = defaultRoom.roomId;
      } else {
        this.newExpense.roomId = this.groups[0].roomId;
      }
    }
  }
  toggleDatePicker() {
    this.showDatePicker = !this.showDatePicker;
  }

  onDateChange() {
    this.showDatePicker = false;
  }

  filterRooms(event: any) {
    const val = event.target.value.toLowerCase();
    this.filteredGroups = this.groups.filter(g =>
      g.name.toLowerCase().includes(val)
    );
  }

  async addExpense() {
    const amount = Number(this.newExpense.amount);
    if (!this.newExpense.item && !this.newExpense.amount && !this.newExpense.roomId) {
      this.toast.error('Please fill all required fields');
      return;
    }

    const itemValue = this.newExpense.item.trim();
    if (itemValue.length > this.MAX_ITEM_LENGTH) {
      this.toast.error(`Item name is too long (max ${this.MAX_ITEM_LENGTH} characters)`);
      return;
    }


    // 1. Block repeating characters (e.g., "aaaaaaa" or "jjjjjj")
    const repeatingRegex = /(.)\1{4,}/;

    // 2. Block strings with no vowels (most English words need vowels)
    const noVowelsRegex = /^[^aeiouAEIOU]+$/;

    if (repeatingRegex.test(itemValue)) {
      this.toast.error('Please enter a valid name.');
      return;
    }

    if (itemValue.length > 5 && noVowelsRegex.test(itemValue)) {
      this.toast.error('That doesn’t look like a real word');
      return;
    }

    if (itemValue.length < 3) {
      this.toast.error('Item name is too short');
      return;
    }

    if (!this.newExpense.item?.trim()) {
      this.toast.error('Please enter the expense item');
      return;
    }

    if (!this.newExpense.amount || isNaN(amount) || amount <= 1) {
      this.toast.error('Amount must be greater than 1.00');
      return;
    }

    if (!this.newExpense.date) {
      this.toast.error('Please select a date');
      return;
    }

    if (!this.newExpense.roomId) {
      this.toast.error('Please select a room');
      return;
    }

    this.expenseService.addExpense({ ...this.newExpense }).subscribe({
      next: (res: AddExpenseResponse) => {
        if (res.success) {
          console.log(res);
          this.toast.success(res.message);
          this.dismiss(res);
        }
        else {
          this.toast.error(res.message);
        }
      },
      error: (err: AddExpenseResponse) => {
        this.toast.error('Expense add failed. Please try again.');
      }
    });
  }

  formatDate(date: string): string {
    const d = new Date(date);
    return d.toLocaleDateString('en-US', { year: 'numeric', month: 'short', day: 'numeric' });
  }
}
