import { Injectable } from '@angular/core';
import { Preferences } from '@capacitor/preferences';
import { AppNotification } from '../models/app-notification';
import { HttpClient } from '@angular/common/http';
import { AuthService } from './auth-service';

@Injectable({
  providedIn: 'root'
})
export class NotificationService {
  private baseUrl = 'https://financetracker.runasp.net/api/notifications';

  constructor(private http: HttpClient, private authService: AuthService) { }

  getAll() {
    const userid = this.authService.getUserId();
    return this.http.get<AppNotification[]>(`${this.baseUrl}/get-notifications?userId=${userid}`);
  }

  markAllAsRead() {
    const userid = this.authService.getUserId();
    return this.http.put(`${this.baseUrl}/mark-all-read?userId=${userid}`, {});
  }

  clearAll() {
    const userId = this.authService.getUserId();
    const url = `${this.baseUrl}/clear-all?userId=${userId}`;
    return this.http.delete(url);
  }

  addNotification(roomId: number, title?: string, body?: string) {
    const payload = { RoomId: roomId, Title: title, Body: body };
    const url = `${this.baseUrl}/send`;

    return this.http.post(url, payload).subscribe({
      next: (res) => console.log('✅ Notification Sent:', res),
      error: (err) => console.error('❌ Error sending notification:', err),
    });
  }

  deleteNotification(id: number) {
    const url = `${this.baseUrl}/delete-notification?notificationId=${id}`;
    return this.http.delete(url);
  }
}
